-- Adminer 3.6.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `breaks_time`;
CREATE TABLE `breaks_time` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `breaks_time` (`id`, `name`) VALUES
(1,	'9:45'),
(2,	'10:45'),
(3,	'11:45'),
(4,	'12:45'),
(5,	'13:45'),
(6,	'14:45'),
(7,	'15:45');

DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `students_count` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `classes` (`id`, `name`, `students_count`) VALUES
(1,	'11-A',	30),
(2,	'11-B',	27),
(3,	'11-C',	15),
(4,	'11-D',	10);

DROP TABLE IF EXISTS `days`;
CREATE TABLE `days` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `days` (`id`, `name`) VALUES
(1,	'Monday'),
(2,	'Tuesday'),
(3,	'Wednesday'),
(4,	'Thursday'),
(5,	'Friday'),
(6,	'Saturday'),
(7,	'Sunday');

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_esperanto_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `lessons` (`id`, `name`) VALUES
(1,	'Chemistry'),
(2,	'Physics'),
(3,	'Mathematic'),
(4,	'Economics'),
(5,	'Geography'),
(6,	'History'),
(7,	'Literature');

DROP TABLE IF EXISTS `lessons_time`;
CREATE TABLE `lessons_time` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `lessons_time` (`id`, `name`) VALUES
(1,	'9:00'),
(2,	'10:00'),
(3,	'11:00'),
(4,	'12:00'),
(5,	'13:00'),
(6,	'14:00'),
(7,	'15:00'),
(8,	'16:00');

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule` (
  `day_id` int(3) NOT NULL,
  `time_id` int(3) NOT NULL,
  `lesson_id` int(3) NOT NULL,
  `class_id` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(2) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` int(2) NOT NULL,
  `raiting` int(2) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `class` varchar(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `students` (`id`, `name`, `position`, `raiting`, `active`, `class`) VALUES
(0,	'Ivan',	0,	0,	1,	'1'),
(0,	'Petro',	0,	0,	1,	'2'),
(0,	'Pasha',	0,	0,	1,	'3'),
(0,	'Denis',	0,	0,	1,	'4'),
(0,	'Maxim',	0,	0,	1,	'1'),
(0,	'Stas',	0,	0,	1,	'2'),
(0,	'Anton',	0,	0,	1,	'3'),
(0,	'Artem',	0,	0,	1,	'4'),
(0,	'Sasha',	0,	0,	1,	'1'),
(0,	'Nikita',	0,	0,	1,	'2'),
(0,	'Andrey',	0,	0,	1,	'3');

-- 2014-08-01 11:10:34
